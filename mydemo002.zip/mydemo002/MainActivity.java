package com.example.mydemo002;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.pytorch.IValue;
import org.pytorch.Module;
import org.pytorch.Tensor;
import org.pytorch.torchvision.TensorImageUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    //1.定义button
    Button picButton;
    Button button2;
    TextView textView;

    ImageView imageView;

    Module module;
    Bitmap bitmap;

    RadioButton radioButton_R;
    RadioButton radioButton_M;

    String model_path;
//    Intent chooseIntent;

    private int REQUEST_CODE_PERMISSION = 100;
    private final String REQUIRED_PERMISSIONS = "android.permission.CAMERA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(!checkPermissions()){
            // 请求相机权限
            ActivityCompat.requestPermissions(this, new String[]{REQUIRED_PERMISSIONS}, REQUEST_CODE_PERMISSION);
        }

        //2.按钮绑定
        picButton = findViewById(R.id.picButton);
        button2 = findViewById(R.id.button2);
        imageView = findViewById(R.id.imageView);
        radioButton_R = findViewById(R.id.radioButton_resnet);
        radioButton_M = findViewById(R.id.radioButton_mobilenet);


        textView = findViewById(R.id.textView);
        //3.按钮监听 需要implements View.OnClickListener
        picButton.setOnClickListener(this);
        button2.setOnClickListener(this);
        radioButton_R.setOnClickListener(this);
        radioButton_M.setOnClickListener(this);
//        try {
//            InputStream inputStream = getAssets().open("1.jpeg");
//            bitmap = BitmapFactory.decodeStream(inputStream);
//            imageView.setImageBitmap(bitmap);
//            inputStream.close();
//        }catch (IOException e){
//            throw new RuntimeException();
//        }

    }

    @Override
    public void onClick(View v) {
        if(radioButton_M.isChecked()){
            model_path="mobilenet_jit_v2.pt";
            Toast.makeText(MainActivity.this, "你选择了MobileNet", Toast.LENGTH_SHORT).show();
        }else if(radioButton_R.isChecked()){
            model_path="resnet34_v2_3060_jit.pt";
            Toast.makeText(MainActivity.this, "你选择了ResNet", Toast.LENGTH_SHORT).show();
        }

        //模型推理
        if(v.getId()==R.id.button2){

            //选择图片
            //Intent 想象成一个请求，告诉Android系统我们希望获取用户选择的内容，比如照片、视频或文件。
            Intent chooseIntent = new Intent(Intent.ACTION_GET_CONTENT);
            chooseIntent.setType("image/*"); // 设置要获取的内容类型
            //启动选择内容的活动
            startActivityForResult(chooseIntent, 1);
//            Module module = LiteModuleLoader.load(assetFilePath(this, "model.pt"));
        }else if(v.getId()==R.id.picButton){
            //打开相机（创建一个Intent对象，并指定要启动的相机应用程序）
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, 2);
        }
    }
    /**
     * Copies specified asset to the file in /files app directory and returns this file absolute path.
     *
     * @return absolute file path
     */
    public static String assetFilePath(Context context, String assetName) throws IOException {
        File file = new File(context.getFilesDir(), assetName);
        if (file.exists() && file.length() > 0) {
            return file.getAbsolutePath();
        }

        try (InputStream is = context.getAssets().open(assetName)) {
            try (OutputStream os = new FileOutputStream(file)) {
                byte[] buffer = new byte[4 * 1024];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    os.write(buffer, 0, read);
                }
                os.flush();
            }
            return file.getAbsolutePath();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {

            Uri imageUri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
                imageView.setImageBitmap(bitmap);
//                 //处理模型
//                module = Module.load(assetFilePath(this, model_path));
//                //处理图片
//                // 调整图片大小为224x224
//                Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true);
//                Tensor inputTensor = TensorImageUtils.bitmapToFloat32Tensor(scaledBitmap,
//                        TensorImageUtils.TORCHVISION_NORM_MEAN_RGB, TensorImageUtils.TORCHVISION_NORM_STD_RGB);
//                //推理forward
//                Tensor outputTensor = module.forward(IValue.from(inputTensor)).toTensor();
//                float[] scores = outputTensor.getDataAsFloatArray();
//                //处理输出
//                float maxScore = -Float.MAX_VALUE;
//                int maxScoreIdx = -1;
//                for (int i = 0; i < scores.length; i++) {
//                    if (scores[i] > maxScore) {
//                        maxScore = scores[i];
//                        maxScoreIdx = i;
//                    }
//                }
//                String className = PlantNetClasses.IMAGENET_CLASSES[maxScoreIdx]+String.valueOf(maxScore);
                String className =  infer(bitmap);
                textView.setText(className);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else if(requestCode == 2){
            //触发 onActivityResult
            //data参数中获取名为"data"的额外数据，并将其强制转换为Bitmap类型

//            String className = null;
            try {
                bitmap = (Bitmap) data.getExtras().get("data");
                imageView.setImageBitmap(bitmap);
                String className = infer(bitmap);
                textView.setText(className);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }


        }
    }
    private boolean checkPermissions(){
        if (ContextCompat.checkSelfPermission(this,REQUIRED_PERMISSIONS) != PackageManager.PERMISSION_GRANTED){
            return false;
        }
        return true;
    }
    private String infer(Bitmap bitmap) throws IOException {
        //处理模型
        module = Module.load(assetFilePath(this, model_path));
        //处理图片
        // 调整图片大小为224x224
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 224, 224, true);
        Tensor inputTensor = TensorImageUtils.bitmapToFloat32Tensor(scaledBitmap,
                TensorImageUtils.TORCHVISION_NORM_MEAN_RGB, TensorImageUtils.TORCHVISION_NORM_STD_RGB);
        //推理forward
        Tensor outputTensor = module.forward(IValue.from(inputTensor)).toTensor();
        float[] scores = outputTensor.getDataAsFloatArray();
        //处理输出
        float maxScore = -Float.MAX_VALUE;
        int maxScoreIdx = -1;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] > maxScore) {
                maxScore = scores[i];
                maxScoreIdx = i;
            }
        }
        String className = PlantNetClasses.IMAGENET_CLASSES[maxScoreIdx]+String.valueOf(maxScore);
        return className;
    }
}