package com.example.mydemo002;

public class PlantNetClasses {
    public static String[] IMAGENET_CLASSES = new String[]{
            "仙人球",
            "兰花",
            "发财树",
            "吊兰",
            "君子兰",
            "白掌",
            "绿萝",
            "芦荟",
            "虎皮兰"
    };
}
